-- RegistryHook.lua
-- Eluna server-side script for TrinityCore / AzerothCore.
--
-- Intercepts REGISTRY_AUTH addon messages from the WoW client addon
-- and routes them to the registry-agent HTTP API running on this server.
--
-- Installation:
--   Copy this file to your server's lua_scripts/ directory.
--   Reload with: .reload eluna
--   No server restart needed.
--
-- Requirements:
--   - Eluna Lua engine (most custom private servers already have this)
--   - registry-agent running on this machine (default: localhost:8100)
--   - The registry-agent must be started before players attempt login
--
-- Message protocol (from addon → server):
--   "INIT|<playerPubKey>|<characterId>"   — player initiating login
--   "SIG|<signature>|<pubkey>"            — player returning signed challenge
--
-- Message protocol (server → addon):
--   "CHALLENGE|<nonce>"                   — server issuing challenge
--   "OK|<characterId>"                    — auth accepted
--   "REJECT|<reason>"                     — auth rejected
--
-- The registry-agent listens on a separate port (default 8100) for
-- server-side calls. This is distinct from the node network port (8080).

-- ============================================================
-- Configuration
-- ============================================================

local AGENT_HOST    = "127.0.0.1"
local AGENT_PORT    = 8100          -- registry-agent server-side API port
local ADDON_PREFIX  = "REGISTRY_AUTH"
local TIMEOUT_SEC   = 10

-- ============================================================
-- HTTP helper
-- ============================================================
-- Eluna exposes a minimal HTTP client on patched servers.
-- We use the same lua_http / socket fallback as the client addon.

local function httpPost(path, body)
    local url = "http://" .. AGENT_HOST .. ":" .. AGENT_PORT .. path

    -- Try lua_http first
    if lua_http and lua_http.request then
        local ok, result = pcall(function()
            return lua_http.request({
                url     = url,
                method  = "POST",
                headers = { ["Content-Type"] = "application/json" },
                body    = body,
                timeout = TIMEOUT_SEC,
            })
        end)
        if ok and result then
            return result[1], result[2]  -- body, status code
        end
        return nil, nil
    end

    -- Try LuaSocket
    if package.loaded["socket.http"] or pcall(require, "socket.http") then
        local http  = require("socket.http")
        local ltn12 = require("ltn12")
        local resp  = {}
        local _, code = http.request({
            url     = url,
            method  = "POST",
            headers = {
                ["Content-Type"]   = "application/json",
                ["Content-Length"] = tostring(#body),
            },
            source = ltn12.source.string(body),
            sink   = ltn12.sink.table(resp),
        })
        return table.concat(resp), code
    end

    return nil, nil
end

local function httpGet(path)
    local url = "http://" .. AGENT_HOST .. ":" .. AGENT_PORT .. path

    if lua_http and lua_http.request then
        local ok, result = pcall(function()
            return lua_http.request({ url = url, method = "GET", timeout = TIMEOUT_SEC })
        end)
        if ok and result then return result[1], result[2] end
        return nil, nil
    end

    if package.loaded["socket.http"] or pcall(require, "socket.http") then
        local http = require("socket.http")
        local resp, code = http.request(url)
        return resp, code
    end

    return nil, nil
end

-- ============================================================
-- Minimal JSON helpers (same as client addon)
-- ============================================================

local function jsonEncode(t)
    local parts = {}
    for k, v in pairs(t) do
        local val
        if type(v) == "string" then
            val = '"' .. v:gsub('\\','\\\\'):gsub('"','\\"') .. '"'
        elseif type(v) == "boolean" then
            val = v and "true" or "false"
        else
            val = tostring(v)
        end
        table.insert(parts, '"' .. k .. '":' .. val)
    end
    return "{" .. table.concat(parts, ",") .. "}"
end

local function jsonGet(s, key)
    if not s then return nil end
    local val = s:match('"' .. key .. '"%s*:%s*"([^"]*)"')
    if val then return val end
    val = s:match('"' .. key .. '"%s*:%s*(true|false)')
    if val then return val == "true" end
    val = s:match('"' .. key .. '"%s*:%s*([%d%.%-]+)')
    return val
end

-- ============================================================
-- Send a message back to the player's addon
-- ============================================================

local function sendToAddon(player, msgType, payload)
    local message = msgType .. "|" .. payload
    player:SendAddonMessage(ADDON_PREFIX, message, 7, player)
    -- Channel 7 = CHAT_MSG_ADDON (whisper-style, client only)
end

-- ============================================================
-- Agent API calls
-- ============================================================

-- POST /auth/challenge — request a challenge nonce for this player
-- Returns the nonce string or nil on failure
local function requestChallenge(playerPubKey, characterId)
    local body = jsonEncode({
        player_pub_key  = playerPubKey,
        character_id    = characterId or "new",
    })

    local respBody, code = httpPost("/auth/challenge", body)
    if not respBody or code ~= 200 then
        print("[Registry] Failed to get challenge from agent — code: " .. tostring(code))
        return nil
    end

    return jsonGet(respBody, "nonce")
end

-- POST /auth/verify — verify a signed challenge response
-- Returns: success (bool), characterId (string), reason (string)
local function verifyResponse(playerPubKey, characterId, signature)
    local body = jsonEncode({
        player_pub_key  = playerPubKey,
        character_id    = characterId or "new",
        signature       = signature,
    })

    local respBody, code = httpPost("/auth/verify", body)
    if not respBody then
        return false, nil, "Agent unreachable"
    end

    local success     = jsonGet(respBody, "success")
    local charId      = jsonGet(respBody, "character_id")
    local reason      = jsonGet(respBody, "reason")

    return success == true or success == "true", charId, reason
end

-- ============================================================
-- Pending session state
-- ============================================================
-- Tracks players mid-handshake:
--   key = player GUID (string)
--   value = { pubkey, characterId, timestamp }

local pendingSessions = {}

local function storePending(guid, pubkey, characterId)
    pendingSessions[guid] = {
        pubkey      = pubkey,
        characterId = characterId,
        timestamp   = os.time(),
    }
end

local function getPending(guid)
    return pendingSessions[guid]
end

local function clearPending(guid)
    pendingSessions[guid] = nil
end

-- Expire sessions older than TIMEOUT_SEC
local function cleanupExpired()
    local now = os.time()
    for guid, session in pairs(pendingSessions) do
        if now - session.timestamp > TIMEOUT_SEC then
            pendingSessions[guid] = nil
        end
    end
end

-- ============================================================
-- Main addon message handler
-- ============================================================

local function onAddonMessage(event, sender, type, prefix, message, _, target)
    -- Filter: only our prefix
    if prefix ~= ADDON_PREFIX then return end

    -- Parse message type and payload
    local msgType, payload = message:match("^(%u+)|(.+)$")
    if not msgType or not payload then return end

    local player = sender  -- Eluna passes the player object as sender
    local guid   = tostring(player:GetGUIDLow())

    -- --------------------------------------------------------
    -- INIT — player starting login
    -- "INIT|<pubkey>|<characterId>"
    -- --------------------------------------------------------
    if msgType == "INIT" then
        local pubkey, characterId = payload:match("^([^|]+)|(.*)$")

        if not pubkey or #pubkey ~= 64 then
            sendToAddon(player, "REJECT", "Invalid public key format")
            return
        end

        -- characterId "new" means first login on this server
        if characterId == "new" or characterId == "" then
            characterId = nil
        end

        print("[Registry] INIT from " .. player:GetName() ..
              " pubkey=" .. pubkey:sub(1,8) .. "...")

        -- Request challenge from agent
        local nonce = requestChallenge(pubkey, characterId)
        if not nonce then
            sendToAddon(player, "REJECT", "Server error — could not generate challenge")
            return
        end

        -- Store pending session
        storePending(guid, pubkey, characterId)

        -- Send challenge back to player
        sendToAddon(player, "CHALLENGE", nonce)

        print("[Registry] Challenge issued to " .. player:GetName())

    -- --------------------------------------------------------
    -- SIG — player returning signed challenge
    -- "SIG|<signature>|<pubkey>"
    -- --------------------------------------------------------
    elseif msgType == "SIG" then
        local signature, pubkey = payload:match("^([^|]+)|(.*)$")

        if not signature or not pubkey then
            sendToAddon(player, "REJECT", "Malformed signature message")
            return
        end

        local session = getPending(guid)
        if not session then
            sendToAddon(player, "REJECT", "No pending challenge — start again")
            return
        end

        -- Verify pubkey matches what was used in INIT
        if pubkey ~= session.pubkey then
            clearPending(guid)
            sendToAddon(player, "REJECT", "Public key mismatch")
            return
        end

        print("[Registry] Verifying signature for " .. player:GetName())

        -- Ask agent to verify
        local success, characterId, reason = verifyResponse(
            session.pubkey,
            session.characterId,
            signature
        )

        clearPending(guid)

        if success then
            print("[Registry] Auth SUCCESS for " .. player:GetName() ..
                  " characterId=" .. tostring(characterId))
            sendToAddon(player, "OK", characterId or "")
        else
            print("[Registry] Auth REJECTED for " .. player:GetName() ..
                  " reason=" .. tostring(reason))
            sendToAddon(player, "REJECT", reason or "Verification failed")
        end
    end
end

-- ============================================================
-- Periodic cleanup
-- ============================================================

local function onUpdate(event, diff)
    -- Run cleanup roughly every 30 seconds
    -- Eluna's WORLD_EVENT_ON_UPDATE fires frequently — gate it
    if not RegistryCleanupTimer then RegistryCleanupTimer = 0 end
    RegistryCleanupTimer = RegistryCleanupTimer + diff
    if RegistryCleanupTimer >= 30000 then  -- 30 seconds in ms
        RegistryCleanupTimer = 0
        cleanupExpired()
    end
end

-- ============================================================
-- Event registration
-- ============================================================

-- PLAYER_EVENT_ON_CHAT = 18 in Eluna
-- Fires when the server receives any chat message including addon messages
RegisterPlayerEvent(18, onAddonMessage)

-- WORLD_EVENT_ON_UPDATE = 4 in Eluna
RegisterWorldEvent(4, onUpdate)

print("[Registry] RegistryHook.lua loaded — listening on prefix: " .. ADDON_PREFIX)
