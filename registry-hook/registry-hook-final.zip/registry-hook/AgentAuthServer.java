package org.registryagent.hook;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;
import org.registryagent.auth.AuthServer;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.logging.Logger;

/**
 * Server-side HTTP API consumed by the Eluna Lua hook (RegistryHook.lua).
 *
 * Runs on a separate port (default 8100) from the registry node network (8080).
 * Binds to localhost only — the Eluna hook runs on the same machine.
 *
 * Routes:
 *   POST /auth/challenge   — Lua hook requests a challenge for a player
 *   POST /auth/verify      — Lua hook submits a signed challenge response
 *   GET  /health           — simple health check
 *
 * This is the bridge between the game server's Lua scripting layer
 * and the Java registry-agent. The agent holds all auth state;
 * the Lua hook is stateless and just forwards calls.
 *
 * Add this server to Main.java startup alongside the existing components.
 */
public class AgentAuthServer {

    private static final Logger log = Logger.getLogger(AgentAuthServer.class.getName());

    public  static final int    PORT = 8100;
    private static final String HOST = "127.0.0.1";

    private final HttpServer server;
    private final AuthServer authServer;
    private final ObjectMapper mapper = new ObjectMapper();

    public AgentAuthServer(AuthServer authServer) throws IOException {
        this.authServer = authServer;

        InetSocketAddress address = new InetSocketAddress(HOST, PORT);
        server = HttpServer.create(address, 0);

        // POST /auth/challenge
        server.createContext("/auth/challenge", exchange -> {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendError(exchange, 405, "Method not allowed");
                return;
            }
            handleChallenge(exchange);
        });

        // POST /auth/verify
        server.createContext("/auth/verify", exchange -> {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendError(exchange, 405, "Method not allowed");
                return;
            }
            handleVerify(exchange);
        });

        // GET /health
        server.createContext("/health", exchange -> {
            sendJson(exchange, 200, Map.of("status", "ok"));
        });

        server.setExecutor(Executors.newVirtualThreadPerTaskExecutor());
    }

    // -------------------------------------------------------------------------
    // POST /auth/challenge
    // -------------------------------------------------------------------------
    // Request body:  { "player_pub_key": "hex...", "character_id": "uuid|new" }
    // Response 200:  { "nonce": "hex..." }
    // Response 400:  { "error": "..." }

    private void handleChallenge(com.sun.net.httpserver.HttpExchange exchange)
            throws IOException {
        Map<?, ?> body = readJson(exchange);
        if (body == null) { sendError(exchange, 400, "Invalid JSON"); return; }

        String playerPubKey = (String) body.get("player_pub_key");
        String characterId  = (String) body.get("character_id");

        if (playerPubKey == null || playerPubKey.isBlank()) {
            sendError(exchange, 400, "Missing player_pub_key");
            return;
        }

        // Normalise "new" → null
        if ("new".equals(characterId) || "".equals(characterId)) {
            characterId = null;
        }

        // Delegate to AuthServer
        AuthServer.ChallengeResult result =
                authServer.requestChallenge(playerPubKey, characterId);

        if (!result.isIssued()) {
            sendJson(exchange, 400, Map.of("error", result.getReason()));
            return;
        }

        log.info("Challenge issued for pubkey=" + playerPubKey.substring(0, 8) + "...");
        sendJson(exchange, 200, Map.of("nonce", result.getNonce()));
    }

    // -------------------------------------------------------------------------
    // POST /auth/verify
    // -------------------------------------------------------------------------
    // Request body:  { "player_pub_key": "hex...", "character_id": "uuid|null",
    //                  "signature": "hex..." }
    // Response 200:  { "success": true,  "character_id": "uuid" }
    //             or { "success": false, "reason": "..." }

    private void handleVerify(com.sun.net.httpserver.HttpExchange exchange)
            throws IOException {
        Map<?, ?> body = readJson(exchange);
        if (body == null) { sendError(exchange, 400, "Invalid JSON"); return; }

        String playerPubKey = (String) body.get("player_pub_key");
        String characterId  = (String) body.get("character_id");
        String signature    = (String) body.get("signature");

        if (playerPubKey == null || signature == null) {
            sendError(exchange, 400, "Missing required fields");
            return;
        }

        if ("new".equals(characterId) || "".equals(characterId)) {
            characterId = null;
        }

        // Generate a new characterId if this is a first login
        if (characterId == null) {
            characterId = java.util.UUID.randomUUID().toString();
        }

        // Delegate to AuthServer
        AuthServer.LoginResult result =
                authServer.handleChallengeResponse(playerPubKey, characterId, signature);

        if (!result.isSuccess()) {
            log.warning("Auth rejected — pubkey=" + playerPubKey.substring(0, 8) +
                        "... reason=" + result.getReason());
            sendJson(exchange, 200, Map.of(
                "success", false,
                "reason",  result.getReason()
            ));
            return;
        }

        log.info("Auth success — pubkey=" + playerPubKey.substring(0, 8) +
                 "... characterId=" + characterId);

        sendJson(exchange, 200, Map.of(
            "success",      true,
            "character_id", characterId,
            "session_token", result.getSessionToken()
        ));
    }

    // -------------------------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------------------------

    public void start() {
        server.start();
        log.info("AgentAuthServer listening on " + HOST + ":" + PORT);
    }

    public void stop() {
        server.stop(2);
        log.info("AgentAuthServer stopped");
    }

    // -------------------------------------------------------------------------
    // HTTP helpers
    // -------------------------------------------------------------------------

    private Map<?, ?> readJson(com.sun.net.httpserver.HttpExchange exchange)
            throws IOException {
        try (InputStream is = exchange.getRequestBody()) {
            String body = new String(is.readAllBytes(), StandardCharsets.UTF_8);
            if (body.isBlank()) return Map.of();
            return mapper.readValue(body, Map.class);
        } catch (Exception e) {
            return null;
        }
    }

    private void sendJson(com.sun.net.httpserver.HttpExchange exchange,
                          int status, Object body) throws IOException {
        byte[] bytes = mapper.writeValueAsBytes(body);
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private void sendError(com.sun.net.httpserver.HttpExchange exchange,
                           int status, String message) throws IOException {
        sendJson(exchange, status, Map.of("error", message));
    }
}
